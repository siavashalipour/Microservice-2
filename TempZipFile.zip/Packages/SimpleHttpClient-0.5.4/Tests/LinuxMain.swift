import XCTest
@testable import SimpleHttpClientTests

XCTMain([
	testCase(HttpClientTests.allTests)
])
