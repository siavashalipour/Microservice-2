# Kitura-TemplateEngine
The Kitura Template Engine protocol. Implemented by Templating Engines in order to
integrate with Kitura's content generation APIs.

Inspired by http://expressjs.com/en/guide/using-template-engines.html.
