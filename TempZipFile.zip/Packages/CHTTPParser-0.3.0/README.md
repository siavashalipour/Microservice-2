# CHTTPParser

**Modulemap for libhttp-parser**

This module binds the [http-parser](https://github.com/nodejs/http-parser) library to Swift.
