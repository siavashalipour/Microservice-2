# Kitura-Build

This repository contains the makefile used to build Kitura as well as the build and utility scripts used for the automation of continuous integration builds on the Travis CI environment. Full details on the project can be found in the [main repo](https://github.com/IBM-Swift/Kitura).
