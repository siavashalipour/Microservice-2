import XCTest
@testable import SimpleLoggerTests

XCTMain([
	 testCase(SimpleLoggerTests.allTests),
])
