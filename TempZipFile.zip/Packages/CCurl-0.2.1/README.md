#CCurl

**C bindings for the libcurl library**

This module map links to the [cURL](https://curl.haxx.se/) library in Swift for the implementation of the HTTP protocol and other networking protocols.

