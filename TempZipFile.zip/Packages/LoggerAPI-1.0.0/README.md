# LoggerAPI
A logger protocol implemented by Logger implementations. In addition, a class with a set
of static functions for logging within your code is provided.

Kitura uses this API throughout its implementation when logging.
 
